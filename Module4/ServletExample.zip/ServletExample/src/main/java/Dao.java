import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class Dao 
{
	public static Connection getconnect()
	{
		Connection con = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/signup","root","");
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return con;
	}
	
	public static int signupdata(Model m)
	{
		Connection con =Dao.getconnect();
		int status = 0;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("insert  into info (name,email,password) values (?,?,?)");
			ps.setString(1,m.getName());
			ps.setString(2,m.getEmail());
			ps.setString(3,m.getPassword());
			
			status = ps.executeUpdate();
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}
	
	public static Model signindata(Model m2)
	{
		Connection con =Dao.getconnect();
		Model m=null;		
		try 
		{
			PreparedStatement ps = con.prepareStatement("select * from info where name=? and password=?");
			ps.setString(1,m2.getName());
			ps.setString(2,m2.getPassword());
			
			ResultSet set = ps.executeQuery();
			if(set.next())
			{
				 m = new Model();
				 m.setName(set.getString(1));
				 m.setPassword(set.getString(2));
			}
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return m;
	}
	
	public static int addproduct(ProductModel m)
	{
		Connection con =Dao.getconnect();
		int status = 0;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("insert  into product (pname,pprice,pqua) values (?,?,?)");
			ps.setString(1,m.getPname());
			ps.setString(2,m.getPprice());
			ps.setString(3,m.getPqua());
			
			status = ps.executeUpdate();
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}
	
	public static List<ProductModel>viewdata()
	{
		List<ProductModel>list = new ArrayList<>();
		Connection con =Dao.getconnect();
		try 
		{
			
			
			PreparedStatement ps = con.prepareStatement("select * from product");
			PreparedStatement ps2 = con.prepareStatement("select * from product order by pprice ASC");
			PreparedStatement ps3 = con.prepareStatement("select * from product order by pprice DESC");
			String data="2";
			ResultSet set = null;
			if(data.equals("0"))
			{
				 set = ps.executeQuery();
			}
			if(data.equals("1"))
			{
				 set = ps2.executeQuery();
			}
			if(data.equals("2"))
			{
				 set = ps3.executeQuery();
			}
			
			
			
			while(set.next())
			{
				int id = set.getInt(1);
				String pname = set.getString(2);
				String pprice = set.getString(3);
				String pqua = set.getString(4);
				ProductModel p = new ProductModel();
				p.setId(id);
				p.setPname(pname);
				p.setPprice(pprice);
				p.setPqua(pqua);
				list.add(p);
			}
		
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return list;
	}
	
	public static int deletedata(int id)
	{
		Connection con =Dao.getconnect();
		int status = 0;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("delete from product where id=?");
			ps.setInt(1,id);
			
			status = ps.executeUpdate();
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}
	
	public static ProductModel searchdata(int id)
	{
		Connection con =Dao.getconnect();
		ProductModel m = null;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("select * from product where id=?");
			ps.setInt(1,id);
			
			ResultSet set =ps.executeQuery();
			
			if(set.next())
			{
				int id1 = set.getInt(1);
				String productname1 = set.getString(2);
				String productprice1 = set.getString(3);
				String productquantity1 = set.getString(4);
				
				m = new ProductModel();
				m.setId(id1);
				m.setPname(productname1);
				m.setPprice(productprice1);
				m.setPqua(productquantity1);
				
			}
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return m;
	}
	
	public static int updateproduct(ProductModel m)
	{
		Connection con =Dao.getconnect();
		int status = 0;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("update product set pname=?,pprice=?,pqua=? where id=?");
			ps.setString(1,m.getPname());
			ps.setString(2,m.getPprice());
			ps.setString(3,m.getPqua());
			ps.setInt(4,m.getId());
			
			status = ps.executeUpdate();
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}
	
	public static List<ProductModel>viewdataorder(String data)
	{
		List<ProductModel>list = new ArrayList<>();
		Connection con =Dao.getconnect();
		try 
		{
			PreparedStatement ps;
			if(data.equals("Low to High"))
			{
				 ps = con.prepareStatement("select * from product order by pprice ASC");
			}
			if(data.equals("High to Low"))
			{
				 ps = con.prepareStatement("select * from product order by pprice DESC");
			}
			else
			{
				 ps = con.prepareStatement("select * from product");
			}
			
			
			ResultSet set = ps.executeQuery();
			
			while(set.next())
			{
				int id = set.getInt(1);
				String pname = set.getString(2);
				String pprice = set.getString(3);
				String pqua = set.getString(4);
				ProductModel p = new ProductModel();
				p.setId(id);
				p.setPname(pname);
				p.setPprice(pprice);
				p.setPqua(pqua);
				list.add(p);
			}
		
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return list;
	}
	
	
}
