import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class Dao 
{
	public static Connection getconnect()
	{
		Connection con = null;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/signup","root","");
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return con;
	}
	
	public static int signupdata(Model m)
	{
		Connection con =Dao.getconnect();
		int status = 0;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("insert  into info (name,email,password) values (?,?,?)");
			ps.setString(1,m.getName());
			ps.setString(2,m.getEmail());
			ps.setString(3,m.getPassword());
			
			status = ps.executeUpdate();
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}
	
	public static Model signindata(Model m2)
	{
		Connection con =Dao.getconnect();
		Model m=null;		
		try 
		{
			PreparedStatement ps = con.prepareStatement("select * from info where name=? and password=?");
			ps.setString(1,m2.getName());
			ps.setString(2,m2.getPassword());
			
			ResultSet set = ps.executeQuery();
			if(set.next())
			{
				 m = new Model();
				 m.setName(set.getString(1));
				 m.setPassword(set.getString(2));
			}
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return m;
	}
	
	public static int addproduct(ProductModel m)
	{
		Connection con =Dao.getconnect();
		int status = 0;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("insert  into product (pname,pprice,pqua) values (?,?,?)");
			ps.setString(1,m.getPname());
			ps.setString(2,m.getPprice());
			ps.setString(3,m.getPqua());
			
			status = ps.executeUpdate();
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}
	
	public static List<ProductModel>viewdata()
	{
		List<ProductModel>list = new ArrayList<>();
		Connection con =Dao.getconnect();
		try 
		{
			PreparedStatement ps = con.prepareStatement("select * from product");
			ResultSet set = ps.executeQuery();
			
			while(set.next())
			{
				int id = set.getInt(1);
				String pname = set.getString(2);
				String pprice = set.getString(3);
				String pqua = set.getString(4);
				ProductModel p = new ProductModel();
				p.setId(id);
				p.setPname(pname);
				p.setPprice(pprice);
				p.setPqua(pqua);
				list.add(p);
			}
		
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return list;
	}
	
	
}
