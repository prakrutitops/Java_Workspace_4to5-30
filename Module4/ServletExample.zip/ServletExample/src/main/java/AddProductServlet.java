import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/add")
public class AddProductServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		String pname = req.getParameter("product_name");
		String pprice = req.getParameter("product_price");
		String pqua = req.getParameter("product_quantity");
		
		
		ProductModel m = new ProductModel();
		m.setPname(pname);
		m.setPprice(pprice);
		m.setPqua(pqua);
		
		int data = Dao.addproduct(m);
		
		if(data>0)
		{
				resp.sendRedirect("ViewProductServlet");
		}
		else
		{
			out.print("404.html");
		}
		
			
	}
		
		
	}

