import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		//super.doGet(req, resp);
	
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		String data = req.getParameter("value");
		
	
		if(data.equals("Low to High"))
		{
			Dao.viewdataorder(data);
			RequestDispatcher rd = req.getRequestDispatcher("ViewProductServlet");
			req.setAttribute("data",data);
			rd.forward(req, resp);
			//resp.sendRedirect("ViewProductServlet");
		}
		if(data.equals("High to Low"))
		{
			Dao.viewdataorder(data);
			RequestDispatcher rd = req.getRequestDispatcher("ViewProductServlet");
			req.setAttribute("data",data);
			rd.forward(req, resp);
			//resp.sendRedirect("ViewProductServlet");
		}
		
	}
}
