
public class ProductModel 
{
	int id;
	String pname,pprice,pqua;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPprice() {
		return pprice;
	}
	public void setPprice(String pprice) {
		this.pprice = pprice;
	}
	public String getPqua() {
		return pqua;
	}
	public void setPqua(String pqua) {
		this.pqua = pqua;
	}
	
	
}
