import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewProductServlet")
public class ViewProductServlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		//super.doGet(req, resp);
		  // Set response content type
        resp.setContentType("text/html");

        // Get PrintWriter object to write HTML response
        PrintWriter out =resp.getWriter();
        
        // Write HTML table
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset=\"UTF-8\">");
        out.println("<title>Table Template in Servlet</title>");
        out.println("<style>");
        out.println("/* Table styling */");
        out.println("table {");
        out.println("    width: 100%;");
        out.println("    border-collapse: collapse;");
        out.println("    border-spacing: 0;");
        out.println("    font-family: Arial, sans-serif;");
        out.println("}");
        out.println("th, td {");
        out.println("    border: 1px solid #dddddd;");
        out.println("    text-align: left;");
        out.println("    padding: 8px;");
        out.println("}");
        out.println("th {");
        out.println("    background-color: #f2f2f2;");
        out.println("}");
        out.println("/* Alternate row coloring */");
        out.println("tr:nth-child(even) {");
        out.println("    background-color: #f2f2f2;");
        out.println("}");
        out.println("/* Hover effect */");
        out.println("tr:hover {");
        out.println("    background-color: #ddd;");
        out.println("}");
        out.println("/* Header styling */");
        out.println("h2 {");
        out.println("    text-align: center;");
        out.println("}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<a href='home.html'>Add Data</a>");
        out.println("<form action='SearchServlet'>");
//        out.println("<select name='value'>");
//        out.print("<option>Low to High</option>");
//        out.print("<option>High to Low</option>");
//        out.println("</select>");
        out.print("<input type='submit' value='go'/>");
        out.println("</form>");
        out.println("<h2>Product Details</h2>");
        out.println("<table>");
        out.println("<thead>");
        out.println("<tr>");
        out.println("<th>Id</th>");
        out.println("<th>Product Name</th>");
        out.println("<th>Price</th>");
        out.println("<th>Quantity</th>");
        out.println("<th>Edit</th>");
        out.println("<th>Delete</th>");
        out.println("</tr>");
        out.println("</thead>");
        out.println("<tbody>");
       
        List<ProductModel>list = Dao.viewdata();
        for(ProductModel p :list)
        {
        	out.print("<tr><td>"+p.getId()+"</td><td>"+p.getPname()+"</td><td>"+p.getPprice()+"</td><td>"+p.getPqua()+"</td><td><a href='EditServlet?id="+p.getId()+"'>Edit</a></td><td><a href='DeleteServlet?id="+p.getId()+"'>Delete</a></td></tr>");
        }
      
        out.println("</tbody>");
        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
	
	}
}
